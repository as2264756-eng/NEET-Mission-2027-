NEET MISSION 2027 - ANDROID PROJECT

Is folder ko Android Studio mein open karke APK banaya ja sakta hai.

APK banane ke steps:
1. Android Studio install karo (developer.android.com/studio).
2. Is ZIP ko extract karo.
3. Android Studio > Open > extracted 'NEET-Mission-2027-Android' folder.
4. Gradle sync complete hone do. SDK Platform 35 install karne ka prompt aaye to install karo.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK app/build/outputs/apk/debug/app-debug.apk mein milega.

DATA PRESERVATION:
- App ke andar WebView apna local storage use karta hai.
- Purane browser/website ka localStorage Android app mein automatically transfer nahi hota.
- Purani website mein Backup button dabakar JSON backup save karo.
- App install/open karne ke baad Restore button se wahi JSON file import karo.
- Is tarah chapters, notes, logs, mocks aur custom questions ka saved data migrate ho sakta hai.
- Naye app mein future progress app ke private WebView storage mein save hogi.

NOTES:
- Is environment mein Android SDK/Gradle build tools available nahi the,
  isliye yeh Android Studio project source hai, compiled APK nahi.
- App ke HTML/JS features original uploaded website se bundled hain.
- Alarm/browser background behaviour Android power settings ke hisaab se vary kar sakta hai.
