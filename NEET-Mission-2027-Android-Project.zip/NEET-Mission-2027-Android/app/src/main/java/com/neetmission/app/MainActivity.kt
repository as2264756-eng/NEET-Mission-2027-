\
    package com.neetmission.app

    import android.app.Activity
    import android.content.Intent
    import android.net.Uri
    import android.os.Bundle
    import android.webkit.JavascriptInterface
    import android.webkit.ValueCallback
    import android.webkit.WebChromeClient
    import android.webkit.WebView
    import android.webkit.WebViewClient
    import android.widget.Toast
    import androidx.activity.ComponentActivity
    import androidx.activity.result.contract.ActivityResultContracts
    import org.json.JSONObject

    class MainActivity : ComponentActivity() {
        private lateinit var webView: WebView
        private var fileCallback: ValueCallback<Array<Uri>>? = null
        private var backupJson: String? = null

        private val createBackup = registerForActivityResult(
            ActivityResultContracts.CreateDocument("application/json")
        ) { uri ->
            if (uri != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        out.write((backupJson ?: "{}").toByteArray(Charsets.UTF_8))
                    }
                    Toast.makeText(this, "Backup saved", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Could not save backup", Toast.LENGTH_LONG).show()
                }
            }
            backupJson = null
        }

        private val openBackup = registerForActivityResult(
            ActivityResultContracts.GetContent()
        ) { uri ->
            if (uri == null) {
                fileCallback?.onReceiveValue(null)
                fileCallback = null
                return@registerForActivityResult
            }
            fileCallback?.onReceiveValue(arrayOf(uri))
            fileCallback = null
        }

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            webView = WebView(this)
            setContentView(webView)

            webView.settings.javaScriptEnabled = true
            webView.settings.domStorageEnabled = true
            webView.settings.allowFileAccess = false
            webView.settings.allowContentAccess = true
            webView.webViewClient = WebViewClient()
            webView.addJavascriptInterface(NativeBridge(), "AndroidBridge")
            webView.webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    view: WebView?,
                    callback: ValueCallback<Array<Uri>>?,
                    params: FileChooserParams?
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = callback
                    openBackup.launch("application/json")
                    return true
                }
            }
            webView.loadUrl("file:///android_asset/index.html")
            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    // Route the app's existing Backup button to Android's document picker.
                    webView.evaluateJavascript(
                        "window.exportData=function(){AndroidBridge.saveBackup(JSON.stringify(data));};",
                        null
                    )
                }
            }
        }

        inner class NativeBridge {
            @JavascriptInterface
            fun saveBackup(json: String) {
                runOnUiThread {
                    backupJson = json
                    createBackup.launch("neet-mission-2027-backup.json")
                }
            }
        }

        @Deprecated("Deprecated in Android")
        override fun onBackPressed() {
            if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
            else super.onBackPressed()
        }

        override fun onDestroy() {
            if (::webView.isInitialized) webView.destroy()
            super.onDestroy()
        }
    }
